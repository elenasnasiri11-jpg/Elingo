Elingo — پروژه اندروید

برای ساخت APK از گوشی، می‌توانی از GitHub Actions استفاده کنی؛ فایل workflow در مسیر زیر قرار دارد:
.github/workflows/build-apk.yml

مراحل کلی:
1) در GitHub یک repository جدید بساز.
2) فایل‌های داخل این پوشه را در ریشه repository قرار بده (خود پوشه Elingo را به‌عنوان زیرپوشه قرار نده).
3) وارد تب Actions شو و workflow با نام Build Elingo APK را اجرا کن؛ یا پس از push شدن فایل‌ها، workflow خودکار اجرا می‌شود.
4) وقتی اجرا تمام شد و سبز شد، صفحه اجرای workflow را باز کن و از بخش Artifacts فایل Elingo-debug-apk را دانلود کن.
5) ZIP مربوط به Artifact را در گوشی باز کن و فایل app-debug.apk را نصب کن. ممکن است اندروید برای نصب از منبعی خارج از Play Store اجازه بخواهد.

این فایل‌ها به‌تنهایی APK نیستند؛ APK فقط پس از موفقیت ساخت ابری تولید می‌شود.

مشخصات: namespace com.elingo.app، minSdk 23، targetSdk 28، compileSdk 35.
